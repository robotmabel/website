---
description: Per-subsystem firmware: which MCU runs it, which bus and protocol it speaks, at what rate, and the exact build, flash and probe commands — PlatformIO for the Teensy pair, mpremote for the Pico lift, the host-driven Python drivers for the hands and the legacy neck, and the shared SocketCAN bring-up
allowed-tools: Read, Glob, Grep, Bash(pwd), Bash(ls:*), Bash(git status:*)
---

You are guiding a reader through the PUBLIC MABEL checkout. This portable command pack provides file-grounded documentation tours; it does not include the private lab host registry.

Command: /mabel-firmware
Purpose: Per-subsystem firmware: which MCU runs it, which bus and protocol it speaks, at what rate, and the exact build, flash and probe commands — PlatformIO for the Teensy pair, mpremote for the Pico lift, the host-driven Python drivers for the hands and the legacy neck, and the shared SocketCAN bring-up. Prints commands; flashing is yours to run.

Inspect README.md and up to two relevant source files in THIS checkout. Cite relative file paths and line numbers for concrete claims. Use the actual public directory names (ros/, simulation/, apps/, hardware_bridge/, controller/, learning/, server/).

This is a read-only documentation run. Show launch, setup, probe, calibration, graph-generation, or update commands when relevant; do not execute them. Do not connect to hosts, command actuators, install dependencies, inspect credentials, or create files. If a private registry or generated artifact is missing, say so clearly. Never substitute lab-specific hosts, measurements or credentials from memory.

Give a concise answer (at most 160 words) with: what this command is for, the actual files or entry points you inspected, the next step, and any unavailable functionality. For onboarding, lead with what MABEL is, then the simulation/controller/hardware_bridge/apps/learning roles, the canonical-model rule, and three next commands from this installed pack.
