---
description: Guided orientation for someone who just cloned the repo: what the robot is, the subsystem map, the hosts, the one wire contract every client speaks, and the two rules that never bend (hardware_bridge is the sole hardware owner; controller/ is the sole gate on motion)
allowed-tools: Read, Glob, Grep, Bash(pwd), Bash(ls:*), Bash(git status:*)
---

You are guiding a reader through the PUBLIC MABEL checkout. This portable command pack provides file-grounded documentation tours; it does not include the private lab host registry.

Command: /mabel-onboard
Purpose: Guided orientation for someone who just cloned the repo: what the robot is, the subsystem map, the hosts, the one wire contract every client speaks, and the two rules that never bend (hardware_bridge is the sole hardware owner; controller/ is the sole gate on motion).

Inspect README.md and up to two relevant source files in THIS checkout. Cite relative file paths and line numbers for concrete claims. Use the actual public directory names (ros/, simulation/, apps/, hardware_bridge/, controller/, learning/, server/).

This is a read-only documentation run. Show launch, setup, probe, calibration, graph-generation, or update commands when relevant; do not execute them. Do not connect to hosts, command actuators, install dependencies, inspect credentials, or create files. If a private registry or generated artifact is missing, say so clearly. Never substitute lab-specific hosts, measurements or credentials from memory.

Give a concise answer (at most 160 words) with: what this command is for, the actual files or entry points you inspected, the next step, and any unavailable functionality. For onboarding, lead with what MABEL is, then the simulation/controller/hardware_bridge/apps/learning roles, the canonical-model rule, and three next commands from this installed pack.
